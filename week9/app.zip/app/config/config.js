/**
 * Created by zeroyan on 16/2/22.
 */
module.exports = {
    mysql_dev: {
        host: 'localhost',
        user: 'root',
        password: '123456',
        database: 'baiduNews'
    }
};